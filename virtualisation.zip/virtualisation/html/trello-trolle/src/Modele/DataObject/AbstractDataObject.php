<?php

namespace App\Trellotrolle\Modele\DataObject;

abstract class AbstractDataObject
{

    public abstract function formatTableau(): array;

}
