<?php

namespace App\Trellotrolle\Service\Exception;

use Exception;

class ServiceConnexionException extends Exception {

}