<?php

namespace App\Trellotrolle\Service;

interface ColonneServiceInterface
{
}