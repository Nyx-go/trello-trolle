<?php

use App\Trellotrolle\Controleur\RouteurURL;

require_once __DIR__ . '/../vendor/autoload.php';

RouteurURL::traiterRequete();