import {applyAndRegister, reactive, startReactiveDom} from "./reactive.js";

reactive( {

}, "cuboidHTML");

startReactiveDom();